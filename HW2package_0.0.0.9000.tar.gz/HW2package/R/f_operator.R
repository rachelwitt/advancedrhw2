#' F Operator
#' 
#' This function allows you to transform functions so that they return a normal output if the input is greater than 0
#' and return an error condition object, with "invalid_input" subclass and invalid value attached if the input is invalid
#' @param f The function you want to transform
#' @import rlang

f_operator = function(f){
  force(f)
  func = function(x){
    ifelse(x>0, f(x), catch_cnd(abort(message="Negative input, NA introduced")))
  }
  return(func)
}