#' Square Root 2
#' 
#' This function is a square root function that triggers an error with the use of a negative input
#' 
#' @param x The number that you want to calculate the square root of
#' @import rlang


sqrt_2 = function(x){
  ifelse(x>=0, sqrt(x), abort(message="Negative input, NA introduced"))
}
