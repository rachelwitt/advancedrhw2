#' Log2
#' 
#' This function is a log function that triggers an error with the use of a negative input
#' 
#' @param x The number that you want to calculate the log of
#' @import rlang

log_2 = function(x){
  ifelse(x>0, log(x), abort(message="Negative or 0 input, NA introduced"))
}